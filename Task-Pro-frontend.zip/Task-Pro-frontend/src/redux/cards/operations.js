import { createAsyncThunk } from "@reduxjs/toolkit";
import { api } from "../../services/api.js";

export const addCard = createAsyncThunk(
  "cards/add",
  async ({ columnId, title, description, priority, deadline }, thunkAPI) => {
    try {
      const { data } = await api.post("/cards", {
        columnId,
        title,
        description,
        priority,
        deadline,
      });
      return data.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response?.data?.message || "Failed to add card");
    }
  },
);

export const editCard = createAsyncThunk("cards/edit", async ({ cardId, ...updates }, thunkAPI) => {
  try {
    const { data } = await api.patch(`/cards/${cardId}`, updates);
    return data.data;
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data?.message || "Failed to edit card");
  }
});

export const deleteCard = createAsyncThunk("cards/delete", async (cardId, thunkAPI) => {
  try {
    await api.delete(`/cards/${cardId}`);
    return cardId;
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data?.message || "Failed to delete card");
  }
});

export const moveCard = createAsyncThunk("cards/move", async ({ cardId, targetColumnId }, thunkAPI) => {
  try {
    const { data } = await api.patch(`/cards/${cardId}/move`, {
      columnId: targetColumnId,
    });
    return data.data;
  } catch (error) {
    return thunkAPI.rejectWithValue(error.response?.data?.message || "Failed to move card");
  }
});
