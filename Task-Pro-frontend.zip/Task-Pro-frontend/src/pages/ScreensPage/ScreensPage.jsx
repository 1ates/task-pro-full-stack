import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import HeaderDashboard from "../../components/HeaderDashboard/HeaderDashboard.jsx";
import MainDashboard from "../../components/MainDashboard/MainDashboard.jsx";
import { fetchBoardById } from "../../redux/boards/operations.js";
import { selectCurrentBoard, selectCurrentBoardLoading } from "../../redux/boards/selectors.js";
import { clearCurrentBoard } from "../../redux/boards/slice.js";
import { BOARD_BACKGROUND_IMAGES } from "../../constants/boardBackgrounds.js";
import { getBackgroundUrls } from "../../utils/backgroundHelper.js";
import { Loader } from "../../components/Loader/Loader.jsx";
import clsx from "clsx";
import css from "./ScreensPage.module.css";

const ScreensPage = () => {
  const dispatch = useDispatch();
  const { boardId } = useParams();
  const activeBoard = useSelector(selectCurrentBoard);
  const isLoading = useSelector(selectCurrentBoardLoading);
  const backgroundName = activeBoard?.background || null;
  const [filters, setFilters] = useState({
    priority: "all",
    startDate: null,
    endDate: null,
  });

  const urls = getBackgroundUrls(backgroundName);
  const backgroundStyle = urls
    ? {
        "--bg-mobile-1x": `url(${urls.mobile1x})`,
        "--bg-mobile-2x": `url(${urls.mobile2x})`,
        "--bg-tablet-1x": `url(${urls.tablet1x})`,
        "--bg-tablet-2x": `url(${urls.tablet2x})`,
        "--bg-desktop-1x": `url(${urls.desktop1x})`,
        "--bg-desktop-2x": `url(${urls.desktop2x})`,
      }
    : undefined;

  const backgroundImage = BOARD_BACKGROUND_IMAGES[activeBoard?.background];

  useEffect(() => {
    dispatch(fetchBoardById(boardId));
    return () => {
      dispatch(clearCurrentBoard());
    };
  }, [dispatch, boardId]);

  if (isLoading || !activeBoard) {
    return <Loader />;
  }

  return (
    <section
      className={clsx(css.page, backgroundName && css.hasBackground)}
      style={
        backgroundStyle
          ? {
              backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.45), rgba(0, 0, 0, 0.45)), url(${backgroundImage})`,
            }
          : undefined
      }
    >
      <HeaderDashboard
        boardTitle={activeBoard?.title}
        board={activeBoard}
        filters={filters}
        onFilterChange={setFilters}
      />
      <MainDashboard boardId={activeBoard?._id} board={activeBoard} filters={filters} />
    </section>
  );
};

export default ScreensPage;
