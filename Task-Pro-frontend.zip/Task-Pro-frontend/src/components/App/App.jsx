import { lazy, Suspense, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { refreshUser } from "../../redux/auth/operations.js";
import { selectIsLoggedIn, selectIsRefreshing, selectTheme } from "../../redux/auth/selectors.js";
import PrivateRoute from "../../routers/PrivateRoute.jsx";
import RestrictedRoute from "../../routers/RestrictedRoute.jsx";
import { Loader } from "../Loader/Loader.jsx";
import "./App.module.css";

const WelcomePage = lazy(() => import("../../pages/WelcomePage/WelcomePage.jsx"));
const AuthPage = lazy(() => import("../../pages/AuthPage/AuthPage.jsx"));
const HomePage = lazy(() => import("../../pages/HomePage/HomePage.jsx"));
const ScreensPage = lazy(() => import("../../pages/ScreensPage/ScreensPage.jsx"));
const NotFoundPage = lazy(() => import("../../pages/NotFound/NotFound.jsx"));

function App() {
  const isLoggedIn = useSelector(selectIsLoggedIn);
  const dispatch = useDispatch();
  const isRefreshing = useSelector(selectIsRefreshing);
  const theme = useSelector(selectTheme);

  useEffect(() => {
    dispatch(refreshUser());
  }, [dispatch]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  if (isRefreshing) {
    return <Loader />;
  }

  return (
    <Suspense fallback={null}>
      <Routes>
        <Route path='/' element={<Navigate to={isLoggedIn ? "/home" : "/welcome"} replace />} />

        <Route path='/welcome' element={<RestrictedRoute component={<WelcomePage />} redirectTo='/home' />} />

        <Route path='/auth/:id' element={<RestrictedRoute component={<AuthPage />} redirectTo='/home' />} />

        <Route path='/home' element={<PrivateRoute component={<HomePage />} redirectTo='/welcome' />} />

        <Route path='/home/:boardId' element={<PrivateRoute component={<ScreensPage />} redirectTo='/welcome' />} />

        <Route path='*' element={<NotFoundPage />} />
      </Routes>
    </Suspense>
  );
}

export default App;
