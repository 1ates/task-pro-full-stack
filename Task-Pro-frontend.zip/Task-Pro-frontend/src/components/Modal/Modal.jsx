import { useEffect, useCallback } from "react";
import { createPortal } from "react-dom";
import { Icon } from "../Icon/Icon.js";
import css from "./Modal.module.css";

const modalRoot = document.getElementById("root");

const Modal = ({ isOpen, onClose, className, children }) => {
  const handleKeyDown = useCallback(
    (e) => {
      if (e.key === "Escape") onClose();
    },
    [onClose],
  );

  const handleBackdropClick = (event) => {
    if (event.target === event.currentTarget) {
      onClose();
    }
  };

  useEffect(() => {
    if (!isOpen) return;
    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [isOpen, handleKeyDown]);

  if (!isOpen) return null;

  return createPortal(
    <div className={css.backdrop} onClick={handleBackdropClick} role='dialog' aria-modal='true'>
      <div className={`${css.modal} ${className || ""}`} onClick={(e) => e.stopPropagation()}>
        <button type='button' className={css.closeButton} onClick={onClose} aria-label='Close modal'>
          <Icon name='icon-x' className={css.closeIcon} />
        </button>
        {children}
      </div>
    </div>,
    modalRoot,
  );
};

export default Modal;
