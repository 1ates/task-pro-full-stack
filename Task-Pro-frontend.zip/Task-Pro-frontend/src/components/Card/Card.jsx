import { useState, useRef, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { deleteCard, moveCard } from "../../redux/cards/operations.js";
import { selectColumns } from "../../redux/columns/selectors.js";
import { MovePopover } from "../MovePopover/MovePopover.jsx";
import CardModal from "../CardModal/CardModal.jsx";
import { Icon } from "../Icon/Icon.jsx";
import css from "./Card.module.css";

const PRIORITY_COLORS = {
  without: "var(--priority-without)",
  low: "var(--priority-low)",
  medium: "var(--priority-medium)",
  high: "var(--priority-high)",
};

const PRIORITY_LABELS = {
  without: "Without priority",
  low: "Low",
  medium: "Medium",
  high: "High",
};

const formatDate = (date) =>
  new Date(date).toLocaleDateString("en-US", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });

const isDueToday = (date) => {
  const today = new Date();
  const deadline = new Date(date);
  return (
    today.getFullYear() === deadline.getFullYear() &&
    today.getMonth() === deadline.getMonth() &&
    today.getDate() === deadline.getDate()
  );
};

const Card = ({ card, columnId }) => {
  const dispatch = useDispatch();
  const columns = useSelector(selectColumns);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isMoveOpen, setIsMoveOpen] = useState(false);
  const [showMove, setShowMove] = useState(false);
  const moveRef = useRef(null);

  useEffect(() => {
    if (!isMoveOpen) return;
    const handleClick = (e) => {
      if (moveRef.current && !moveRef.current.contains(e.target)) {
        setIsMoveOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [isMoveOpen]);

  const handleDelete = () => {
    dispatch(deleteCard(card._id));
  };

  const handleMove = (targetColumnId) => {
    dispatch(moveCard({ cardId: card._id, targetColumnId }));
    setIsMoveOpen(false);
  };

  const isDeadlineToday = (() => {
    if (!card.deadline) return false;
    return isDueToday(card.deadline);
  })();

  const formattedDeadline = card.deadline ? formatDate(card.deadline) : null;

  const priorityColor = PRIORITY_COLORS[card.priority] || PRIORITY_COLORS.without;

  const moveTargets = columns.filter((col) => col._id !== columnId);

  return (
    <>
      <article className={css.card}>
        <span className={css.priorityBar} style={{ backgroundColor: priorityColor }} aria-hidden='true' />

        <h4 className={css.title}>{card.title}</h4>

        {card.description && <p className={css.description}>{card.description}</p>}

        <div className={css.footer}>
          <div className={css.metaCol}>
            <span className={css.metaLabel}>Priority</span>
            <span className={css.priorityLabel}>
              <span className={css.priorityDot} style={{ backgroundColor: priorityColor }} />
              {PRIORITY_LABELS[card.priority] || "Without priority"}
            </span>
          </div>

          {formattedDeadline && (
            <div className={css.metaCol}>
              <span className={css.metaLabel}>Deadline</span>
              <span className={css.dateRow}>
                {formattedDeadline}
                {isDeadlineToday && <Icon name='icon-bell' className={css.bellIcon} />}
              </span>
            </div>
          )}

          <div className={css.actions} ref={moveRef}>
            {moveTargets.length > 0 && (
              <button
                type='button'
                className={css.iconButton}
                onClick={() => setIsMoveOpen((prev) => !prev)}
                aria-label='Move card to another column'
                title='Move card'
              >
                <Icon name='icon-move' />
              </button>
            )}

            <button
              type='button'
              className={css.iconButton}
              onClick={() => setIsEditOpen(true)}
              aria-label='Edit card'
              title='Edit card'
            >
              <Icon name='icon-edit' />
            </button>

            <button
              type='button'
              className={css.iconButton}
              onClick={handleDelete}
              aria-label='Delete card'
              title='Delete card'
            >
              <Icon name='icon-trash' />
            </button>

            {isMoveOpen && (
              <ul className={css.moveMenu} role='menu'>
                {moveTargets.map((col) => (
                  <li key={col._id}>
                    <button
                      type='button'
                      className={css.moveMenuItem}
                      onClick={() => handleMove(col._id)}
                      role='menuitem'
                    >
                      {col.title}
                      <span className={css.moveMenuIcon}>
                        <Icon name='icon-arrow-right' />
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </article>

      <CardModal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} columnId={columnId} card={card} />

      {showMove && (
        <MovePopover
          columns={columns}
          currentColumnId={columnId}
          onMove={(toColumnId) => {
            dispatch(moveCard({ cardId: card._id, targetColumnId: toColumnId }));
            setShowMove(false);
          }}
          onClose={() => setShowMove(false)}
        />
      )}
    </>
  );
};

export default Card;
